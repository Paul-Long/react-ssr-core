const log = require('log4js');

log.configure('../config/logger.json');
